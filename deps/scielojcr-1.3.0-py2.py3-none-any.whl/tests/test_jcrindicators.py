# coding: utf-8
import unittest
import os
import sys


PROJECT_PATH = os.path.abspath(os.path.dirname(''))
sys.path.append(PROJECT_PATH)

from scielojcr import jcrindicators


class JCRTest(unittest.TestCase):

    def test_load_issn_scielo(self):

        result = jcrindicators.get_indicators('0103-636X')

        expected = {
              '2010':
              {
                'impact_factor_without_journal_self_cites': None,
                'year': 2010,
                'journal_impact_factor': None,
                'cited_half_life': None,
                'normalized_eigenfactor': None,
                'eigenfactor_score': None,
                'immediacy_index': None,
                'citable_items': 34,
                'five_year_impact_factor': None,
                'issn_scielo': '0103-636X',
                'article_influence_score': None,
                'percentage_articles_in_citable_items': 100.0,
                'citing_half_life': '>10.0',
                'average_journal_impact_factor_percentile': 0.272,
                'total_cites': 1},
              '2011':
              {
                'impact_factor_without_journal_self_cites': None,
                'year': 2011,
                'journal_impact_factor': None,
                'cited_half_life': None,
                'normalized_eigenfactor': None,
                'eigenfactor_score': None,
                'immediacy_index': None,
                'citable_items': 37,
                'five_year_impact_factor': None,
                'issn_scielo': '0103-636X',
                'article_influence_score': None,
                'percentage_articles_in_citable_items': 100.0,
                'citing_half_life': '9.6',
                'average_journal_impact_factor_percentile': 0.243,
                'total_cites': 9}}

        self.assertEqual(expected, result)

    def test_load_issn_scielo_year(self):

        result = jcrindicators.get_indicators('0036-3634', '2016')

        expected = {
                  'citable_items': 75,
                  'impact_factor_without_journal_self_cites': 0.859,
                  'journal_impact_factor': 1.253,
                  'five_year_impact_factor': 1.611,
                  'normalized_eigenfactor': 0.37254,
                  'citing_half_life': '6.9',
                  'eigenfactor_score': 0.00325,
                  'immediacy_index': 0.2,
                  'total_cites': 1792,
                  'year': 2016,
                  'percentage_articles_in_citable_items': 100.0,
                  'issn_scielo': '0036-3634',
                  'average_journal_impact_factor_percentile': 35.35,
                  'article_influence_score': 0.48,
                  'cited_half_life': '6.9'
                }

        self.assertEqual(expected, result)

    def test_load_current_indicators(self):

        result = jcrindicators.get_current_indicators('0036-3634')

        expected = {
                  'citable_items': 75,
                  'impact_factor_without_journal_self_cites': 0.859,
                  'journal_impact_factor': 1.253,
                  'five_year_impact_factor': 1.611,
                  'normalized_eigenfactor': 0.37254,
                  'citing_half_life': '6.9',
                  'eigenfactor_score': 0.00325,
                  'immediacy_index': 0.2,
                  'total_cites': 1792,
                  'year': 2016,
                  'percentage_articles_in_citable_items': 100.0,
                  'issn_scielo': '0036-3634',
                  'average_journal_impact_factor_percentile': 35.35,
                  'article_influence_score': 0.48,
                  'cited_half_life': '6.9'
                }

        self.assertEqual(expected, result)

    def test_load_update_indicators(self):

        result = jcrindicators.UPDATE_INDICATORS

        expected = '2017-06-14'

        self.assertEqual(expected, result)


if __name__ == '__main__':
    unittest.main()
