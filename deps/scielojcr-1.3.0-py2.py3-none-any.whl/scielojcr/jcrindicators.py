# coding: utf-8

import os
import csv
import logging

logger = logging.getLogger(__name__)

_CURRENT_DIR = os.path.abspath(os.path.dirname(__file__))

JOURNALS = {}

CURRENT_INDICATORS = '2016'

UPDATE_INDICATORS = '2017-06-14'

with open(_CURRENT_DIR + '/data/scielo_jcr_indicators.csv', 'r') as csvfile:

    has_header = csv.Sniffer().has_header(csvfile.read())

    csvfile.seek(0)

    spamreader = csv.reader(csvfile, delimiter='\t')

    if has_header:
        next(spamreader)

    for line in spamreader:

        issn_scielo = line[0]

        year = line[1]

        if line[2]:
            total_cites = int(line[2])
        else:
            total_cites = None

        if line[3]:
            journal_impact_factor = float(line[3])
        else:
            journal_impact_factor = None

        if line[4]:
            impact_factor_without_journal_self_cites = float(line[4])
        else:
            impact_factor_without_journal_self_cites = None

        if line[5]:
            five_year_impact_factor = float(line[5])
        else:
            five_year_impact_factor = None

        if line[6]:
            immediacy_index = float(line[6])
        else:
            immediacy_index = None

        if line[7]:
            citable_items = int(line[7])
        else:
            citable_items = None

        if line[8]:
            cited_half_life = line[8]
        else:
            cited_half_life = None

        if line[9]:
            citing_half_life = line[9]
        else:
            citing_half_life = None

        if line[10]:
            eigenfactor_score = float(line[10])
        else:
            eigenfactor_score = None

        if line[11]:
            article_influence_score = float(line[11])
        else:
            article_influence_score = None

        if line[12]:
            percentage_articles_in_citable_items = float(line[12])
        else:
            percentage_articles_in_citable_items = None

        if line[13]:
            average_journal_impact_factor_percentile = float(line[13])
        else:
            average_journal_impact_factor_percentile = None

        if line[14]:
            normalized_eigenfactor = float(line[14])
        else:
            normalized_eigenfactor = None

        JOURNALS.setdefault(issn_scielo, {})

        JOURNALS[issn_scielo][year] = {
            'issn_scielo': issn_scielo,
            'total_cites': total_cites,
            'journal_impact_factor': journal_impact_factor,
            'impact_factor_without_journal_self_cites': impact_factor_without_journal_self_cites,
            'five_year_impact_factor': five_year_impact_factor,
            'immediacy_index': immediacy_index,
            'citable_items': citable_items,
            'cited_half_life': cited_half_life,
            'citing_half_life': citing_half_life,
            'eigenfactor_score': eigenfactor_score,
            'article_influence_score': article_influence_score,
            'percentage_articles_in_citable_items': percentage_articles_in_citable_items,
            'average_journal_impact_factor_percentile': average_journal_impact_factor_percentile,
            'normalized_eigenfactor': normalized_eigenfactor,
            'year': int(year)
        }


def get_indicators(issn_scielo, year=None):

    data = JOURNALS.get(issn_scielo, None)

    if data and year:
        return data.get(year, None)

    return data


def get_current_indicators(issn_scielo):

    return get_indicators(issn_scielo, CURRENT_INDICATORS)
